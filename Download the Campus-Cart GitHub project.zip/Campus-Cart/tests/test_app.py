import app as campuscart


def client(monkeypatch):
    monkeypatch.setattr(campuscart, "BROKEN", False)
    return campuscart.app.test_client()


def test_health_ok(monkeypatch):
    response = client(monkeypatch).get("/health")
    assert response.status_code == 200
    assert response.get_json()["status"] == "ok"


def test_health_reports_version(monkeypatch):
    monkeypatch.setattr(campuscart, "APP_VERSION", "test-version")
    response = client(monkeypatch).get("/health")
    assert response.get_json()["version"] == "test-version"


def test_order_validation(monkeypatch):
    response = client(monkeypatch).post("/orders", json={"item": "", "qty": 0})
    assert response.status_code == 400
