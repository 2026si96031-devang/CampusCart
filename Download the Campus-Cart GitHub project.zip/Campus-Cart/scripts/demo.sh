#!/usr/bin/env sh
set -eu
VERSION="${1:-1.0.0}"
mkdir -p secrets
[ -f secrets/db_password.txt ] || printf '%s' 'ChangeMe-CampusCart-2026' > secrets/db_password.txt
docker build -t "campuscart-api:${VERSION}" --build-arg "APP_VERSION=${VERSION}" .
API_TAG="${VERSION}" docker compose up -d
docker compose ps
curl --retry 12 --retry-delay 2 --retry-all-errors http://localhost:8080/health
